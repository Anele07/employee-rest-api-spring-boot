package com.employee;

public class Employee {
    private int employeeID;
    private String firstName;
    private String lastName;
    private String email;
    private String title;

    public Employee(int employee_id, String first_name, String last_name,
                    String email, String title){
        if(employee_id <= 0){
            throw new IllegalArgumentException("Employee ID must be positive.");
        }
        this.employeeID = employee_id;
        this.firstName = first_name;
        this.lastName = last_name;
        this.email = email;
        this.title = title;
    }

    public int getEmployeeID(){
        return this.employeeID;
    }

    public String getFirstName(){
        return this.firstName;
    }

    public String getLastName(){
        return this.lastName;
    }

    public String getEmail(){
        return this.email;
    }

    public String getTitle(){
        return this.title;
    }

    public void setEmployeeID(int employeeID){
        this.employeeID = employeeID;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public void setTitle(String title){
        this.title = title;
    }
}
